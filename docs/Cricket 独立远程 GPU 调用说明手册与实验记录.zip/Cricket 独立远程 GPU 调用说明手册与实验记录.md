# Cricket 独立远程 GPU 调用说明手册与实验记录

## 术语表

本文第一次出现的英文术语按下表理解：

|术语|中文解释|在本文中的含义|
|---|---|---|
|Client|客户端|位于调用端的 `cricket-client.so`，负责拦截并转发 CUDA 调用|
|Server|服务端|位于 GPU 端的 `cricket-rpc-server`，负责调用真实 CUDA/GPU|
|CUDA Runtime|CUDA 运行时接口|`cudaMalloc`、`cudaMemcpy`、`cudaFree` 等以 `cuda*` 开头的常用 API|
|CUDA Driver API|CUDA 驱动接口|`cuMemAlloc`、`cuModuleLoad` 等更底层的 `cu*` API|
|Kernel|GPU 核函数|由大量 GPU 线程并行执行的函数，例如 `add_one<<<...>>>()`|
|RPC|Remote Procedure Call，远程过程调用|把一次本地函数调用编码后交给另一台机器执行|
|ONC RPC|一种传统 RPC 协议族|Cricket 当前提交使用的 RPC 实现，依赖 `rpcbind` 和 `libtirpc`|
|`rpcbind`|RPC 端口登记服务|保存 RPC program/version 与实际 TCP 端口的对应关系|
|`LD_PRELOAD`|动态库预加载机制|让 Linux 动态链接器优先加载 Cricket 的 CUDA 包装函数|
|ELF|Linux 可执行与可链接文件格式|本文编译得到的程序和 `.so` 共享库格式|
|ABI|Application Binary Interface，应用二进制接口|已编译程序与动态库在二进制层面的调用约定|
|H2D|Host to Device，主机到设备|调用端内存数据传向远端 GPU 显存|
|D2H|Device to Host，设备到主机|远端 GPU 结果返回调用端内存|
|RTT|Round\-Trip Time，网络往返时延|一个请求发送并收到响应所需的时间|
|Smoke Test|冒烟测试|用最小任务快速确认关键链路能否工作|
|Artifact|构建制品|编译产生的可执行文件或共享库，不是源代码|
|Fat Binary|多架构 CUDA 制品|同一程序中包含多个 GPU 架构代码或 PTX|
|PTX|CUDA 中间指令表示|可由兼容的远端驱动进一步即时编译成 GPU 机器码|

## 1\. Cricket 原理

### 1\.1 总体结构

```Plaintext
┌──────────────────── 调用端 ────────────────────┐
│ CUDA 应用                                      │
│  cudaMalloc / cudaMemcpy / kernel / cudaFree  │
│                  │                             │
│                  v                             │
│ LD_PRELOAD=cricket-client.so                  │
│ CUDA 包装函数 -> 参数编码 -> ONC RPC Client   │
└──────────────────┬─────────────────────────────┘
                   │ TCP/IP LAN
                   │ RPC program=99, version=1
                   v
┌──────────────────── GPU 端 ────────────────────┐
│ Windows 固定入口 192.168.5.6:53773            │
│          │ portproxy                           │
│          v                                     │
│ WSL 动态 IP : Cricket 动态端口                 │
│ rpcbind + cricket-rpc-server                  │
│          │                                     │
│ CUDA Runtime / Driver / cuBLAS / cuDNN / NVML│
│          │                                     │
│ NVIDIA GeForce RTX 5060 Ti                    │
└────────────────────────────────────────────────┘
```

### 1\.2 动态符号拦截

普通动态 CUDA 程序在启动时由动态链接器解析 `cudaMalloc`、`cudaMemcpy` 等符号。设置：

```Bash
LD_PRELOAD=/path/to/cricket-client.so
```

后，动态链接器优先使用 Cricket 提供的包装函数。包装函数不会在调用端执行真实 CUDA，而是：

1. 读取 API 参数；

2. 将参数和必要数据编码为 RPC 请求；

3. 发送到 Cricket Server；

4. 等待远端返回 CUDA 错误码或数据；

5. 把结果转换成调用端程序预期的返回值。

因此业务源码不需要包含网络协议代码。决定调用路径的是运行时是否加载 Cricket Client，而不是程序在哪里编译。

### 1\.3 动态 cudart 要求

测试程序必须动态链接 CUDA Runtime：

```Bash
nvcc -cudart shared source.cu -o program
```

检查：

```Bash
ldd ./program | grep libcudart
```

如果程序把 cudart 静态链接进 ELF，`LD_PRELOAD` 不一定能覆盖对应调用。特殊的 `dlopen`、私有封装、未覆盖 Driver API 或框架自定义加载路径也需要单独验证。

### 1\.4 ONC RPC 与 rpcbind

固定版本使用：

```Plaintext
RPC program: 99
RPC version: 1
Transport: TCP
```

Server 启动参数：

```Bash
cricket-rpc-server 1
```

Client 环境变量：

```Plaintext
CRICKET_RPCID=1
```

在该提交中，`CRICKET_RPCID` 实际表示 RPC version，两端必须一致。

只配置主机名时：

```Plaintext
REMOTE_GPU_ADDRESS=192.168.5.6
```

Client 会通过 TCP 111 查询 rpcbind。显式配置端口时：

```Plaintext
REMOTE_GPU_ADDRESS=192.168.5.6:53773
```

Client 直接连接固定入口。当前部署采用第二种方式，业务端不依赖动态 RPC 端口。

### 1\.5 一次 kernel 的数据流

以数组加一为例：

1. `cudaGetDeviceCount` 查询远端设备；

2. `cudaMalloc` 在远端 GPU 建立显存对象；

3. H2D `cudaMemcpy` 将数组通过 TCP 发送到远端；

4. Client 发送 kernel 模块、入口和参数；

5. 远端 GPU 执行 kernel；

6. `cudaDeviceSynchronize` 等待远端完成；

7. D2H `cudaMemcpy` 将结果传回调用端；

8. 调用端执行 CPU reference 校验；

9. `cudaFree` 释放远端资源。

Cricket 不是跨主机统一内存。传输量、API 次数和网络 RTT 会直接影响性能。

## 2\. 两端环境与职责

### 2\.1 调用端

调用端可以没有 NVIDIA GPU，但需要：

- Linux 或 WSL2 用户空间；

- 与目标架构兼容的 CUDA ELF；

- `cricket-client.so`；

- `libtirpc.so.3`；

- 可达 `192.168.5.6:53773` 的网络；

- 正确的 `LD_LIBRARY_PATH`；

- 结果校验和超时机制。

如果调用端要编译 `.cu`，还需要 CUDA Toolkit 和 `nvcc`。没有 GPU 时不能使用 `-arch=native`，必须明确目标架构或生成 fatbin。

### 2\.2 GPU 端

GPU 端需要：

- 可工作的 Windows NVIDIA 驱动和 WSL GPU 映射；

- `/dev/dxg`；

- CUDA Toolkit 12\.8；

- cuDNN 9\.12；

- Cricket Server 和 libtirpc；

- `rpcbind`；

- 固定的 Windows LAN 地址；

- 仅允许可信调用端访问的防火墙规则。

### 2\.3 构建位置、程序位置和计算位置

这三个“位置”必须分开描述：

|阶段|发生位置|作用|
|---|---|---|
|构建|可以在 GPU 端、调用端或独立构建机|把 `.cu` 源码编译成 Linux ELF 制品|
|程序运行|调用端|运行 CPU 业务逻辑，并通过 `LD_PRELOAD` 加载 Cricket Client|
|GPU 计算|GPU 端|Cricket Server 调用真实 CUDA，在 NVIDIA GPU 上执行 Kernel|

程序在哪里编译，不决定 GPU 最终在哪里执行。真正决定调用路径的是程序启动时是否加载 `cricket-client.so`，以及 `REMOTE_GPU_ADDRESS` 指向哪里。

当前独立实验采用下面的工程化折中：

```Plaintext
源码复制到 GPU 端
  -> 使用已安装的 CUDA 12.8 和目标 GPU 编译
  -> 只把 ELF 制品复制回调用端
  -> 调用端加载 Cricket Client 并启动该制品
  -> GPU 端 Cricket Server 执行 CUDA 请求
```

这样做是为了避免在调用端宿主 WSL 中再维护一套 CUDA Toolkit，并确保 Kernel 制品包含当前 RTX 5060 Ti 可执行的目标代码。它适合固定远端的部署验证，但不是 Cricket 的硬性要求，也不是多种异构 GPU 的最终构建方案。

如果源码和业务进程都允许长期放在 GPU 端，直接在 GPU 端编译并运行更简单，此时没有使用 Cricket 的必要。本文之所以把制品传回调用端，是为了验证另一种能力：**业务进程留在调用端，而 GPU 计算发生在另一台机器。**

## 3\. 第一次构建 Cricket

### 3\.1 安装依赖

Ubuntu 22\.04：

```Bash
sudo apt update
sudo apt install -y build-essential autoconf automake libtool pkg-config \
  rpcbind rpcsvc-proto libssl-dev libelf-dev \
  libvdpau-dev libegl1-mesa-dev
```

检查：

```Bash
for cmd in gcc make rpcgen rpcbind nvcc; do
  printf '%-10s' "$cmd"
  command -v "$cmd" || exit 1
done
```

### 3\.2 固定源码

```Bash
mkdir -p ~/src
cd ~/src
git clone https://github.com/RWTH-ACS/cricket.git
cd cricket
git checkout --detach 5d55bd582fc7acbb2a12c45f104020566a67218a

git config submodule.submodules/libtirpc.url \
  https://github.com/alisw/libtirpc.git
git submodule sync --recursive
git submodule update --init --recursive

git rev-parse HEAD
git -C submodules/libtirpc rev-parse HEAD
```

只有默认 submodule 地址不可用时才替换 URL，不应随意升级固定 commit。

### 3\.3 检查 CUDA 与 cuDNN

```Bash
nvidia-smi
nvidia-smi -L
ls -l /dev/dxg
nvcc --version
readlink -f /usr/local/cuda
ldconfig -p | grep -E 'libcuda|libcudart|libcublas|libcusolver|libnvidia-ml'
ldconfig -p | grep libcudnn
```

只有 `nvidia-smi` 而没有 `nvcc`，表示驱动可用但 CUDA 开发 Toolkit 不完整。

### 3\.4 编译

```Bash
cd ~/src/cricket
make -C submodules
make -C cpu LOG=INFO
```

常见缺失：

|错误|处理|
|---|---|
|`vdpau/vdpau.h`|安装 `libvdpau-dev`|
|`EGL/egl.h`|安装 `libegl1-mesa-dev`|
|`cuda_runtime_api.h`|检查 CUDA include|
|`cudnn.h`|安装匹配 CUDA 的 cuDNN dev 包|
|`gcc: no input files`|检查自定义 flags 中是否意外换行|

检查产物：

```Bash
ls -lh cpu/cricket-rpc-server cpu/cricket-client.so
file cpu/cricket-rpc-server cpu/cricket-client.so
ldd cpu/cricket-rpc-server | grep 'not found' || true
ldd cpu/cricket-client.so | grep 'not found' || true
```

整理运行目录：

```Bash
mkdir -p ~/src/cricket/bin
cp -a cpu/cricket-rpc-server cpu/cricket-client.so ~/src/cricket/bin/
cp -a submodules/libtirpc/install/lib/libtirpc.so* ~/src/cricket/bin/
ls -lh ~/src/cricket/bin
```

## 4\. Demo 1：API Smoke

### 4\.1 目标

只验证设备发现、显存分配、显存填充和释放，不执行自定义 kernel。

核心程序：

```C++
#include <cuda_runtime.h>
#include <stdio.h>

int main(void) {
    int count = -1;
    cudaError_t err = cudaGetDeviceCount(&count);
    printf("cudaGetDeviceCount: err=%d count=%d\n", (int)err, count);
    if (err != cudaSuccess || count < 1) return 1;

    void *ptr = NULL;
    err = cudaMalloc(&ptr, 4096);
    printf("cudaMalloc: err=%d ptr=%p\n", (int)err, ptr);
    if (err != cudaSuccess) return 2;

    err = cudaMemset(ptr, 0x5a, 4096);
    printf("cudaMemset: err=%d\n", (int)err);
    if (err != cudaSuccess) return 3;

    err = cudaFree(ptr);
    printf("cudaFree: err=%d\n", (int)err);
    return err == cudaSuccess ? 0 : 4;
}
```

编译：

```Bash
nvcc -cudart shared cricket-smoke.cu -o cricket-smoke
```

当前实验在 GPU 端执行这条编译命令，再通过普通文件传输把 `cricket-smoke` ELF 制品复制到调用端。该步骤不属于 Cricket RPC；正式远程调用从调用端执行下一条命令时才开始。

远程执行：

```Bash
timeout 30s env \
  REMOTE_GPU_ADDRESS=192.168.5.6:53773 \
  CRICKET_RPCID=1 \
  LD_PRELOAD="$HOME/cricket-standalone/bin/cricket-client.so" \
  LD_LIBRARY_PATH="$HOME/cricket-standalone/bin:/usr/local/cuda/lib64" \
  ./cricket-smoke
echo $?
```

通过条件：四个 API 返回 0、count 大于 0、程序退出码 0。

![image\.png](图片和附件/image%201.png)

本轮原始日志结果为四个 CUDA Runtime API 全部返回 0、远端设备数为 1、`api-call-cnt=4`、退出码为 0。

## 5\. Demo 2：Kernel 与逐元素校验

### 5\.1 任务设计

输入为 `0..255`，远端 GPU 执行 `data[i] += 1`，调用端取回结果并与 CPU 期望值比较。

它覆盖：

```Plaintext
设备发现 -> cudaMalloc -> H2D -> kernel -> synchronize -> D2H -> CPU 校验 -> free
```

### 5\.2 完整核心代码

```C++
#include <cuda_runtime.h>
#include <stdio.h>

__global__ void add_one(int *data) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < 256) data[i] += 1;
}

int main(void) {
    int count = 0;
    cudaError_t err = cudaGetDeviceCount(&count);
    printf("device count: err=%d count=%d\n", (int)err, count);
    if (err != cudaSuccess || count < 1) return 1;

    int host[256];
    for (int i = 0; i < 256; ++i) host[i] = i;

    int *device = NULL;
    if (cudaMalloc(&device, sizeof(host)) != cudaSuccess) return 2;
    if (cudaMemcpy(device, host, sizeof(host),
                   cudaMemcpyHostToDevice) != cudaSuccess) return 3;

    add_one<<<1, 256>>>(device);
    err = cudaGetLastError();
    printf("kernel launch: err=%d\n", (int)err);
    if (err != cudaSuccess) return 4;

    err = cudaDeviceSynchronize();
    printf("kernel sync: err=%d\n", (int)err);
    if (err != cudaSuccess) return 5;

    if (cudaMemcpy(host, device, sizeof(host),
                   cudaMemcpyDeviceToHost) != cudaSuccess) return 6;
    if (cudaFree(device) != cudaSuccess) return 7;

    int failures = 0;
    for (int i = 0; i < 256; ++i) {
        if (host[i] != i + 1) ++failures;
    }
    printf("verification failures: %d\n", failures);
    printf("sample: %d %d %d\n", host[0], host[1], host[255]);
    return failures == 0 ? 0 : 8;
}
```

### 5\.3 编译策略

当前实验在目标 GPU 端编译，使用：

```Bash
nvcc -cudart shared -arch=native \
  cricket-kernel-smoke.cu -o cricket-kernel-smoke
```

在没有 GPU 的调用端或构建机编译时必须明确远端架构，或者生成覆盖目标的 fatbin。

两种方式的取舍是：

|方式|优点|局限|本文采用情况|
|---|---|---|---|
|GPU 端编译后复制 ELF|目标环境明确，可使用 `-arch=native`|多个异构远端时可能重复构建；需要传源码或构建上下文|当前固定 RTX 5060 Ti 实验采用|
|调用端/构建机编译|源码不进入 GPU 端，便于统一构建|需要 Toolkit，并且必须提前知道目标架构和兼容范围|本文说明但未作为当前基线|

无论采用哪种方式，通过条件都不能只看“编译成功”。必须在调用端以远端地址启动，并完成 D2H 回传和 CPU 数值校验，才能证明跨机计算链路。

检查动态 cudart：

```Bash
ldd ./cricket-kernel-smoke | grep libcudart
```

### 5\.4 远程执行

```Bash
timeout 30s env \
  REMOTE_GPU_ADDRESS=192.168.5.6:53773 \
  CRICKET_RPCID=1 \
  LD_PRELOAD="$HOME/cricket-standalone/bin/cricket-client.so" \
  LD_LIBRARY_PATH="$HOME/cricket-standalone/bin:/usr/local/cuda/lib64" \
  ./cricket-kernel-smoke
rc=$?
echo "exit=$rc"
exit "$rc"
```

通过条件：

```Plaintext
device count: err=0 count=1
kernel launch: err=0
kernel sync: err=0
verification failures: 0
sample: 1 2 256
exit=0
```

![image\.png](图片和附件/image%202.png)

这是本文最重要的正确性截图。只有连接目标、Kernel、同步、D2H 后的 CPU 校验和退出码出现在同一次运行中，才能构成完整证据。

## 6\. **Demo 3：矩阵全连接层与 CPU 全量校验**

### **6\.1 矩阵任务**

Demo 1 和 Demo 2 证明了基础 API 与小型 Kernel 路径，但输入和计算量都很小。Demo 3 使用经典矩阵乘法，并包装成一个容易解释的全连接层：

```Plain Text
Y = ReLU(X × W + bias)
```

其中：

- `X` 是调用端本地生成的 `512×512` 特征矩阵；

- `W` 是调用端本地生成的 `512×512` 权重矩阵；

- `bias` 是长度为 512 的偏置向量；

- `X × W` 在远端 GPU 上使用分块矩阵乘法 Kernel 计算；

- 第二个远端 Kernel 完成逐列加偏置和 ReLU；

- `Y` 经 D2H 返回调用端；

- 调用端 CPU 对全部 262,144 个输出重新计算并逐项比较。

ReLU（Rectified Linear Unit，修正线性单元）的规则是：

```Plain Text
ReLU(value) = max(0, value)
```

因此该 Demo 既是经典矩阵乘法，也对应机器学习中常见的全连接层数据流。

### **6\.2 数据规模与可读输出**

完整矩阵包含 262,144 个元素，不适合全部打印。程序只展示 `X`、`W` 和 `Y` 左上角的 `4×4` 小块，同时对完整结果做校验。

计算与传输规模：

```Plain Text
矩阵乘加次数：512 × 512 × 512 = 134,217,728
H2D：X + W + bias = 2,099,200 字节
D2H：Y = 1,048,576 字节
完整输出元素：262,144
```

调用端使用固定 seed 生成输入，并在上传前打印 `X` 和 `W` 的 checksum。输入生成发生在调用端进程中；远端收到的是 Cricket 传输的矩阵字节，而不是源文件或预先准备的答案。

### **6\.3 GPU 与 CPU 的职责**

```Plain Text
调用端 CPU：生成 X/W/bias、打印输入样例和 checksum
      ↓ H2D，经 Cricket RPC
远端 GPU：tiled_matmul -> add_bias_relu
      ↓ D2H，经 Cricket RPC
调用端 CPU：完整复算 Y、逐项比较、输出 PASS/FAIL
```

程序使用整数输入和整数累加，因此 CPU 与 GPU 的正确结果必须完全一致，不需要浮点误差容忍。通过条件为：

```Plain Text
GPU result checksum == CPU result checksum
mismatched elements: 0 / 262144
maximum absolute difference: 0
verification: PASS
exit=0
```

### **6\.4 源码、构建与运行**

源码和脚本位于：

```Plain Text
examples/cricket-standalone/matrix-dense/
  matrix_dense.cu
  build-remote.sh
  run-remote.sh
  README.zh-CN.md
```

构建脚本把 CUDA 源码传到 GPU 端临时目录，使用远端 CUDA 12\.8 和 `-arch=native` 编译动态 cudart ELF，再把 ELF 复制回调用端。编译文件传输不是 Cricket 数据调用；正式 Cricket 调用从本地执行 ELF 时开始。

```Bash
cd /mnt/d/vGPU/accelerator-control-plane
./examples/cricket-standalone/matrix-dense/build-remote.sh
```

运行：

```Bash
cd /mnt/d/vGPU/accelerator-control-plane
./examples/cricket-standalone/matrix-dense/run-remote.sh
```

也可以直接使用与前两个 Demo 相同的 `LD_PRELOAD` 方式启动 `docs/evidence/cricket-standalone/bin/cricket-matrix-dense`。

![image\.png](图片和附件/image.png)



## 

